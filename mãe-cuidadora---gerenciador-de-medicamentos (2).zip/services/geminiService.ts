
import { GoogleGenAI } from "@google/genai";

export const askAssistant = async (question: string, medications: any[]) => {
  // Verificação de segurança: Se não houver chave, não tentamos a conexão.
  // Isso evita erros de 'chave não encontrada' durante o upload ou build no GitHub.
  const apiKey = process.env.API_KEY;
  
  if (!apiKey || apiKey === "undefined") {
    console.warn("Aviso: API_KEY não configurada. O assistente está em modo offline.");
    return "Olá! Meu sistema de inteligência está descansando agora (falta configurar a chave). Mas posso te dizer que seus remédios estão salvos aqui no app!";
  }

  const ai = new GoogleGenAI({ apiKey });
  const medsContext = medications.map(m => `- ${m.name}: ${m.dosage}, ${m.frequency}`).join('\n');
  
  const prompt = `
    Você é um assistente virtual gentil e prestativo chamado "Cuidador Amigo", especializado em ajudar idosos a entenderem seus medicamentos.
    A usuária é uma mãe que precisa de orientações simples e claras.
    
    Medicamentos atuais dela:
    ${medsContext}
    
    Pergunta da usuária: "${question}"
    
    Regras:
    1. Responda em português de forma carinhosa.
    2. Use termos fáceis.
    3. Sempre mencione para consultar o médico em caso de dúvidas graves.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "Desculpe, não consegui entender agora.";
  } catch (error) {
    console.error("Erro na API Gemini:", error);
    return "Ops! Tive um probleminha técnico. Tente novamente em um instante.";
  }
};
